#ifndef Motor_h
#define Motor_h
#include "headfile.h"




extern void motor_init();
extern void Target();
extern int16 motor_control();
extern void Motor_Run();
#endif