/*
  * @file       Flagget.c
  * @brief      ��־λ��ʵ��
  * @author     Ma_Pengxiao
  * @version    N++
  * @date       2020-8-6
*/
#include "Flagget.h"
#define BEEP_PIN   B11

int stop_flag=0;
int reed_flag=0;
static uint16 stop_time;
static uint8 detection_enable_sign;
int island_flag=0;
static uint16 island_time;
static uint8 a=0;
static uint16 time;
extern unsigned int pit_hander_timer;
extern uint8 ad[7];
extern uint16 L_Final;	
extern uint16 R_Final;
/*
 *  @brief      ������
 *  @since      1.0
*/
void Beep(){

        gpio_set(BEEP_PIN,1);//�򿪷�����
}
void Beeps(){
				gpio_set(BEEP_PIN,0);//�رշ�����
}
/*
 *  @brief      ����ͣ��
 *  @since      1.0
*/
void Over_limitstop(){

if(ad[0]<90&&ad[2]<90&&ad[4]<90&&ad[3]<90&&pit_hander_timer>3000){
  stop_flag=1;  
}
}
/*
 *  @brief      Բ��ʶ��
 *  @since      N++
*/
void island_control(){
if(R_Final>390&&L_Final>240&&island_flag==0){
	island_flag=1;
	Beep();
}
else if(R_Final<250&&L_Final<250&&island_flag==1){
island_flag=0;//2
Beeps();
}
}
/*
 *  @brief      �ɻɹ�ͣ�����
 *  @since      1.0
*/
void Reed_stop(){
if(detection_enable_sign==0){
stop_time+=1;

if(stop_time>2000){
gpio_init(C15,GPO,1,GPIO_PIN_CONFIG);
gpio_interrupt_init(C15,RISING,GPIO_PIN_CONFIG);
EnableIRQ(GPIO2_Combined_0_15_IRQn);
detection_enable_sign=1;
      }
   }
}
/*
 *  @brief      GPIO�ⲿ�ж�
 *  @since      1.0
*/
void GPIO2_Combined_0_15_IRQHandler()
{
	  detection_enable_sign=2;
    if(GET_GPIO_FLAG(C15))
    {
      CLEAR_GPIO_FLAG(C15);//����жϱ�־λ
			systick_delay_ms(1);
			if(gpio_get(C15)==0){
			Beep();
			reed_flag=1;
			}
    }    
}

