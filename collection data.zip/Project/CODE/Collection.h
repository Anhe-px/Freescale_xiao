#ifndef Collection_h
#define Collection_h
#include "headfile.h"


void ad_init();
void ad_collection();
void ad_pid();
void smotor_control();

#endif