/*
  * @file       Motor.c
  * @brief      �����ؿ���ʵ��
  * @author     Ma_Pengxiao
  * @version    N++
  * @date       2020-8-6
*/

#include "Motor.h"
#define Max_pwm       25000//����޷�
#define Speed         90  //�ٶ�
#define Stop_speed    0    //��Ӣ����ʾ
int Corners_speed = Speed+8;

#define POWER_motor0_PIN  PWM1_MODULE0_CHB_D13//����һ �������  1
#define POWER_motor1_PIN  PWM1_MODULE0_CHA_D12//�����  0
#define POWER_motor2_PIN  PWM1_MODULE1_CHB_D15//������  0
#define POWER_motor3_PIN  PWM1_MODULE1_CHA_D14//������  1
float L_pwm,R_pwm;
int frequency = 10000;
int Target_L , Target_R;
static float Bias_L,Integral_bias_L,Last_Bias_L;
static float Bias_R,Integral_bias_R,Last_Bias_R;
float diff_k=0.09;//0.09

extern int16 encoder_L,encoder_R;
extern unsigned int pit_hander_timer;

extern int16 smotor_angle;	
extern int16 smotor_angle_last;
extern int island_flag;
extern int reed_flag;
extern int stop_flag;

/*
 *  @brief      ��ʼ��
 *  @since      1.0
*/
void motor_init(){
pwm_init(PWM1_MODULE0_CHA_D12, frequency, 0);    
pwm_init(PWM1_MODULE0_CHB_D13, frequency, 0);
pwm_init(PWM1_MODULE1_CHA_D14, frequency, 0);
pwm_init(PWM1_MODULE1_CHB_D15, frequency, 0);	 
}
/*
 *  @brief      �����ٶȼ���ٿ���
 *  @since      2.0
*/
void Target(){
//	//Left	
//	if(smotor_angle<-210&&smotor_angle>=-410){
//	Target_L=Corners_speed-5.0*diff_k*(-Bias_L);//2.5
//	Target_R=Corners_speed+0.8*diff_k*(-Bias_R);//0.8
//	}
//	//Right
//	else if(smotor_angle>210&&smotor_angle<=410){
//	Target_L=Corners_speed+0.8*diff_k*Bias_L;//0.4
//	Target_R=Corners_speed-5.0*diff_k*Bias_R;//1.5
//	}
/*	else */if(island_flag==1)
	{
		Target_L=Speed+7;
		Target_R=Speed+7;
	}
	else{
	Target_L=Speed;
  Target_R=Speed;
	}
}
/*
 *  @brief      �������ʽpid
 *  @since      v1.0
*/
int16 motor_control(Target_L,Target_R){
	double Kp_L=3.1,Ki_L=2.1,Kd_L=1.2;
	double Kp_R=3.1,Ki_R=2.1,Kd_R=1.2;
	
	Bias_L=-(encoder_L-Target_L);
	Bias_R=((-encoder_R)-Target_R);
	
	Integral_bias_L+=Bias_L;
	Integral_bias_R+=Bias_R;

	L_pwm=(int)(Kp_L*Bias_L+Ki_L*Integral_bias_L+Kd_L*(Bias_L-Last_Bias_L));
	R_pwm=(int)(Kp_R*Bias_R+Ki_R*Integral_bias_R+Kd_R*(Bias_R-Last_Bias_R));
	
	Last_Bias_L=Bias_L;
	Last_Bias_R=Bias_R;
	
	return L_pwm;
	return R_pwm;
}
/*
 *  @brief      ������
 *  @since      v1.0
*/
void Motor_Run(){
L_pwm=limit(L_pwm,Max_pwm);
R_pwm=limit(R_pwm,Max_pwm);
	
if(L_pwm>=0){
	pwm_duty(POWER_motor2_PIN,0);                        
  pwm_duty(POWER_motor3_PIN,L_pwm); 
}else{
	pwm_duty(POWER_motor2_PIN,-L_pwm);                        
  pwm_duty(POWER_motor3_PIN,0); 
}
	
if(R_pwm>=0){
	pwm_duty(POWER_motor0_PIN,R_pwm);
  pwm_duty(POWER_motor1_PIN,0);
}else{
	pwm_duty(POWER_motor0_PIN,0);
  pwm_duty(POWER_motor1_PIN,-R_pwm);
}
	if(stop_flag==1||reed_flag==1){
pwm_duty(POWER_motor1_PIN,0);
pwm_duty(POWER_motor3_PIN,0);
	}

}