/*
  * @file       Collection.c
  * @brief      �ɼ���������ʵ��
  * @author     Ma_Pengxiao
  * @version    N++
  * @date       2020-8-6
*/

#include "Collection.h"
#define duty_middle   3750//�����ֵ  3350
#define duty_offset   420	//�������ֵ
#define Max_pwm       25000//����޷�

/*
 *  @brief      ���IO��
 *  @since      1.0
*/
#define POWER_ADC1_MOD  ADC_2       
#define POWER_ADC1_PIN  ADC2_CH15_B26
#define POWER_ADC2_MOD  ADC_2   
#define POWER_ADC2_PIN  ADC2_CH14_B25
#define POWER_ADC3_MOD  ADC_2      
#define POWER_ADC3_PIN  ADC2_CH13_B24
#define POWER_ADC4_MOD  ADC_2       
#define POWER_ADC4_PIN  ADC2_CH11_B22
#define POWER_ADC5_MOD  ADC_2       
#define POWER_ADC5_PIN  ADC2_CH10_B21

#define POWER_ADC6_MOD  ADC_2       
#define POWER_ADC6_PIN  ADC2_CH0_B27
#define POWER_ADC7_MOD  ADC_2       
#define POWER_ADC7_PIN  ADC2_CH1_B28
                                             
#define POWER_ADC8_MOD  ADC_1       
#define POWER_ADC8_PIN  ADC1_CH4_B15
#define POWER_ADC9_MOD  ADC_1       
#define POWER_ADC9_PIN  ADC1_CH3_B14 

#define S_MOTOR_PIN   PWM4_MODULE2_CHA_C30 
uint8 ad[7];
uint16 L_Value[3];
uint16 L_Final;	
uint16 R_Value[3];
uint16 R_Final;
uint16 L_FinalOld,L_FinalNew;
uint16 R_FinalOld,R_FinalNew;
uint16 L_getvalue,R_getvalue;
int Ind_dierction;
short error;
short error_last=0; 
int16 smotor_angle;	
int16 smotor_angle_last;

extern int island_flag;

/*
 *  @brief      ad��ʼ��
 *  @since      1.0
*/
void ad_init(){
    adc_init(POWER_ADC1_MOD,POWER_ADC1_PIN,ADC_8BIT);  
    adc_init(POWER_ADC2_MOD,POWER_ADC2_PIN,ADC_8BIT);
    adc_init(POWER_ADC3_MOD,POWER_ADC3_PIN,ADC_8BIT);
    adc_init(POWER_ADC4_MOD,POWER_ADC4_PIN,ADC_8BIT);
	  adc_init(POWER_ADC5_MOD,POWER_ADC5_PIN,ADC_8BIT);
	  adc_init(POWER_ADC6_MOD,POWER_ADC6_PIN,ADC_8BIT);
	  adc_init(POWER_ADC7_MOD,POWER_ADC7_PIN,ADC_8BIT);
	  adc_init(POWER_ADC8_MOD,POWER_ADC8_PIN,ADC_10BIT);	
	  adc_init(POWER_ADC9_MOD,POWER_ADC9_PIN,ADC_10BIT);
}
/*
 *  @brief      7·��ֵ�˲�
 *  @since      1.0
*/
void ad_collection()
{
	  ad[0] = adc_mean_filter(POWER_ADC1_MOD,POWER_ADC1_PIN,10);
    ad[1] = adc_mean_filter(POWER_ADC2_MOD,POWER_ADC2_PIN,10);
    ad[2] = adc_mean_filter(POWER_ADC3_MOD,POWER_ADC3_PIN,10);
    ad[3] = adc_mean_filter(POWER_ADC4_MOD,POWER_ADC4_PIN,10);	
    ad[4] = adc_mean_filter(POWER_ADC5_MOD,POWER_ADC5_PIN,10);	
    ad[5] = adc_mean_filter(POWER_ADC6_MOD,POWER_ADC6_PIN,10);	
    ad[6] = adc_mean_filter(POWER_ADC7_MOD,POWER_ADC7_PIN,10);	
}
/*
 *  @brief      pid���Ʋɼ�����
 *  @since      N++
*/
void ad_pid(){
	L_getvalue=adc_mean_filter(POWER_ADC8_MOD,POWER_ADC8_PIN,5);
	R_getvalue=adc_mean_filter(POWER_ADC9_MOD,POWER_ADC9_PIN,5);
	
	L_Value[0] = L_Value[1];
  L_Value[1] = L_Value[2];
	L_Value[2]= adc_convert(POWER_ADC8_MOD ,POWER_ADC8_PIN);
	
	R_Value[0] = R_Value[1];
  R_Value[1] = R_Value[2];
	R_Value[2]= adc_convert(POWER_ADC9_MOD ,POWER_ADC9_PIN);
	
	L_FinalNew = 0.45*L_getvalue + 0.35*L_Value[2] + 0.15*L_Value[1] + 0.05*L_Value[0];
  R_FinalNew = 0.45*R_getvalue + 0.35*R_Value[2] + 0.15*R_Value[1] + 0.05*R_Value[0];
	
	if(L_FinalNew>=L_FinalOld){
		L_Final=(L_FinalNew-L_FinalOld)>70?(L_FinalOld+70):L_FinalNew;
	}else{
		L_Final=(L_FinalNew-L_FinalOld)<-70?(L_FinalOld-70):L_FinalNew;
	}
	
	if(R_FinalNew>=R_FinalOld){
		R_Final=(R_FinalNew-R_FinalOld)>70?(R_FinalOld+70):R_FinalNew;
	}else{
		R_Final=(R_FinalNew-R_FinalOld)<-70?(R_FinalOld-70):R_FinalNew;
	}

	if(island_flag==1){
	L_Final=limit(L_Final,500);
	R_Final=limit(R_Final,500);
	}
	
	L_FinalOld= L_Final;
	R_FinalOld= R_Final;
}
/*
 *  @brief      ����pid����
 *  @since      N++
*/
void smotor_control(){
smotor_angle = (int16)limit(smotor_angle,duty_offset);
float Kp=1.2;
float Kd=0.4;
error=R_Final-L_Final;
if(abs(error)<30){
error=0;
Kp=0;
Kd=0;
}
else if(abs(error)<150)
{
Kp=0.3;//Kp=0.08;
Kd=0.1;//Kd=0.01;
}
//else if(abs(error)<150)
//{

//}
else if(475>abs(error)&&abs(error)>=150)//275
{
Kp=0.8;
Kd=0.2;
}
smotor_angle=Kp*error+Kd*(error-error_last);//������
if(smotor_angle>=duty_offset) smotor_angle=duty_offset;
else if(smotor_angle<=-duty_offset) smotor_angle=-duty_offset;
Ind_dierction=(int)(duty_middle-smotor_angle);
error_last=error;
smotor_angle_last=smotor_angle;
pwm_duty(S_MOTOR_PIN,Ind_dierction);
}