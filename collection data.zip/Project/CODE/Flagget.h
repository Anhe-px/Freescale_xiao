#ifndef Flagget_h
#define Flagget_h
#include "headfile.h"


void Beep();
void Over_limitstop();
void Reed_stop();
void island_control();
void GPIO2_Combined_0_15_IRQHandler();

#endif